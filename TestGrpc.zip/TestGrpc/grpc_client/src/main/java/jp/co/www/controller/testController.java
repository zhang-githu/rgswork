package jp.co.www.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.grpc.ManagedChannel;
import jp.co.www.config.GrpcChannel;
import jp.co.www.protodefine.Hello.HelloRequest;
import jp.co.www.protodefine.Hello.HelloResponse;
import jp.co.www.protodefine.HelloServiceGrpc;

@RestController
public class testController {

	@Autowired
	private GrpcChannel grpcChannel;

	@GetMapping("/hello")
	public ResponseEntity<String> hello(String name) {

		ManagedChannel channel = null;
		try {

			channel = grpcChannel.get();

			System.out.println("%%% authority = " + channel.authority());

			HelloServiceGrpc.HelloServiceBlockingStub stub = HelloServiceGrpc.newBlockingStub(channel);

			for (int i = 1; i < 128; i++) {
				HelloRequest request = HelloRequest.newBuilder().setName(name + i).build();
				HelloResponse response = stub.sayHello(request);
				System.out.println(response.getGreeting());
				Thread.sleep(1000);
			}

			System.out.println("%%% authority = " + channel.authority());

			return ResponseEntity.ok("OK!!");
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.toString(), HttpStatus.EXPECTATION_FAILED);
		} finally {

		}
	}

	@GetMapping("/")
	public ResponseEntity<String> hello() {
		return ResponseEntity.ok("OK!");
	}
}
