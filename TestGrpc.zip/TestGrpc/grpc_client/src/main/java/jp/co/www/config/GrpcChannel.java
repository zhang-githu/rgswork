package jp.co.www.config;

import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

@Component
public class GrpcChannel {

//	String target = "localhost:9002";
	String target = "localhost:31272";

	private ManagedChannel channel;

	public ManagedChannel get() {
		if (channel == null)
			return creatChannel();
		else
			return channel;
	}

	private ManagedChannel creatChannel() {

		ManagedChannel channel = ManagedChannelBuilder.forTarget(target).usePlaintext().build();

		return channel;
	}

	@PreDestroy
	private void destroy() {
		if (channel != null)
			channel.shutdown();
	}

}
